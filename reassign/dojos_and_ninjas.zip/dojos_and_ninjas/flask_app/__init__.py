#importing flask into app
from flask import Flask
#flask apps name
app = Flask(__name__)